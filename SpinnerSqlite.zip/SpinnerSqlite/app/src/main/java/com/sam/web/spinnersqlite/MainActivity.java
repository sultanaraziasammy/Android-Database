package com.sam.web.spinnersqlite;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;import android.os.Bundle;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import android.os.Bundle;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Spinner;
import android.widget.TextView;
public class MainActivity extends Activity {

    Spinner spinner;
    TextView selection;
    RadioGroup radioGroup;
    EditText editText;
    Context context;
    Button register;
    UserAdapter user;
    String[] items = { "Kids(0-18)", "Youth(18-30)", "Young(30-45)",
            "OldAge(45 and above)" };
@Override
protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration_form);



        radioGroup = (RadioGroup) findViewById(R.id.radioGroup1);
        editText = (EditText) findViewById(R.id.mobile);

        spinner = (Spinner) findViewById(R.id.spinner1);

        ArrayAdapter<String> aa = new ArrayAdapter<String>(this,
        android.R.layout.simple_spinner_item, items);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(aa);

        user = new UserAdapter(this);
        user = user.open();

        register = (Button) findViewById(R.id.button1);
        register.setOnClickListener(new OnClickListener() {

        String ageGroup;

@Override
public void onClick(View v) {
        // TODO Auto-generated method stub
        boolean didItWork = true;
        String gender = null;
        String mobile;


        mobile = editText.getText().toString();

        Dialog d1 = new Dialog(MainActivity.this);
        d1.setTitle("Sucess");
        TextView tv1 = new TextView(MainActivity.this);
        tv1.setText(mobile);
        d1.setContentView(tv1);
        d1.show();

        if(radioGroup.getCheckedRadioButtonId() != -1){
        int id =radioGroup.getCheckedRadioButtonId();
        View radioButton = radioGroup.findViewById(id);
        int radioId = radioGroup.indexOfChild(radioButton);
        RadioButton btn = (RadioButton) radioGroup.getChildAt(radioId);
        gender = (String) btn.getText();


        Dialog d2 = new Dialog(MainActivity.this);
        d2.setTitle("Sucess");
        TextView tv2 = new TextView(MainActivity.this);
        tv2.setText(gender);
        d2.setContentView(tv2);
        d2.show();

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

@Override
public void onItemSelected(AdapterView<?> arg0,
        View arg1, int position, long arg3) {
        ageGroup = (String) spinner.getItemAtPosition(position);

        Dialog d = new Dialog(MainActivity.this);
        d.setTitle("Sucess");
        TextView tv = new TextView(MainActivity.this);
        tv.setText(ageGroup);
        d.setContentView(tv);
        d.show();

        }

@Override
public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

        }
        });

        }
        user.insertEntry(gender,ageGroup,mobile);
        user.close();

        }
        });



        }

@Override
public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
        }



        }
