package com.sam.web.spinnersqlite;

/**
 * Created by maudud on 2/12/18.
 */

public class State
{
    public String name = "";


    public State(String _name)
    {

        name = _name;

    }
    public String toString()
    {
        return name;
    }
}