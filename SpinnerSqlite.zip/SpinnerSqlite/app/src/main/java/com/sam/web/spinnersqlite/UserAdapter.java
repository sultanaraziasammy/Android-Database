package com.sam.web.spinnersqlite;

/**
 * Created by maudud on 2/12/18.
 */

class UserAdapter {
}
