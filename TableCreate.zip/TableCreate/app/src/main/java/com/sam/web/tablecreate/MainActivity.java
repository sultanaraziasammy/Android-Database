package com.sam.web.tablecreate;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Sqlite mydb;
    TextView name,surName,marks;
    EditText edtName,edtSurName,edtMarks;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

            mydb=new Sqlite(this);

            name=(TextView)findViewById(R.id.name);
            surName=(TextView)findViewById(R.id.surName);
            marks=(TextView)findViewById(R.id.marks);
            edtName=(EditText)findViewById(R.id.edt_name);
            edtSurName=(EditText)findViewById(R.id.edt_surName);
            edtMarks=(EditText)findViewById(R.id.edt_marks);
        }
    }


