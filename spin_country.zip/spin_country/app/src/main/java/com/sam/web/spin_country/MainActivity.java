package com.sam.web.spin_country;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;



    public class MainActivity extends AppCompatActivity implements View.OnClickListener {
        private EditText nameEditText,emailEditText,usernameEditText,passwordEditText;
        private Button signUpButton;
        UserDetails userDetails;
        Database database;



        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            nameEditText=(EditText) findViewById(R.id.nameEditTextId);
            emailEditText=(EditText) findViewById(R.id.signUpEmailEditTextId);

            usernameEditText=(EditText) findViewById(R.id.signUpUsernameEditTextId);
            passwordEditText=(EditText) findViewById(R.id.signUpPasswordEditTextId);


            signUpButton=(Button) findViewById(R.id.signUpButtonId);
            database=new Database(this);

            userDetails=new UserDetails();
            signUpButton.setOnClickListener(this);


            Spinner spinner = (Spinner) findViewById(R.id.spinner);
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                    this, R.array.countries_array, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    return;
                }
                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });


        }

        @Override
        public void onClick(View v) {
            String name = nameEditText.getText().toString();
            String email = emailEditText.getText().toString();
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            userDetails.setName(name);
            userDetails.setEmail(email);
            userDetails.setUsername(username);
            userDetails.setPassword(password);

            long rowId = database.insertData(userDetails);

            if (rowId > 0)
            {
                Toast.makeText(getApplicationContext(),"Row "+rowId+" is successfully inserted",Toast.LENGTH_LONG).show();

            }
            else {

                Toast.makeText(getApplicationContext(),"Row "+rowId+" Data is not inserted",Toast.LENGTH_LONG).show();



            }


        }
    }
